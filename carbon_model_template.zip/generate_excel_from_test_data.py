#!/usr/bin/env python3
"""
Generate Excel File from Test Data

Uses Analyst_Model_Test_OCC.xlsx to generate a complete Excel file
with all sheets populated, ready for review.
"""

import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from data.multi_file_loader import MultiFileLoader
from data.loader import DataLoader
from core.dcf import DCFCalculator
from core.irr import IRRCalculator
from core.payback import PaybackCalculator
from risk.flagger import RiskFlagger
from risk.scorer import RiskScoreCalculator
from export.excel import ExcelExporter

def main():
    """Generate Excel file from test data."""
    print("=" * 70)
    print("GENERATING EXCEL FILE FROM TEST DATA")
    print("=" * 70)
    print()
    
    # Step 1: Load test data
    print("Step 1: Loading test data...")
    data_file = project_root / "Analyst_Model_Test_OCC.xlsx"
    
    if not data_file.exists():
        print(f"ERROR: Test data file not found: {data_file}")
        return False
    
    multi_loader = MultiFileLoader()
    data = multi_loader.load_excel(str(data_file))
    
    if data is None or data.empty:
        print("ERROR: Could not load data")
        return False
    
    print(f"   ✓ Data loaded: {len(data)} rows")
    print()
    
    # Step 2: Extract assumptions
    print("Step 2: Extracting assumptions...")
    data_loader = DataLoader()
    assumptions = data_loader.extract_assumptions(str(data_file))
    
    # Set defaults if missing
    assumptions.setdefault('wacc', 0.08)
    assumptions.setdefault('rubicon_investment_total', 20_000_000)
    assumptions.setdefault('investment_tenor', 5)
    assumptions.setdefault('streaming_percentage_initial', 0.48)
    
    print(f"   ✓ Assumptions extracted")
    print(f"      WACC: {assumptions.get('wacc', 0):.2%}")
    print(f"      Investment: ${assumptions.get('rubicon_investment_total', 0):,.0f}")
    print(f"      Streaming: {assumptions.get('streaming_percentage_initial', 0):.2%}")
    print()
    
    # Step 3: Run DCF analysis
    print("Step 3: Running DCF analysis...")
    irr_calc = IRRCalculator()
    dcf_calc = DCFCalculator(
        wacc=assumptions['wacc'],
        rubicon_investment_total=assumptions['rubicon_investment_total'],
        investment_tenor=assumptions['investment_tenor'],
        irr_calculator=irr_calc
    )
    
    dcf_results = dcf_calc.run_dcf(data, assumptions['streaming_percentage_initial'])
    actual_irr = dcf_results['irr']
    target_irr = 0.20
    
    print(f"   ✓ DCF complete")
    print(f"      NPV: ${dcf_results['npv']:,.2f}")
    print(f"      IRR: {actual_irr:.2%}")
    print()
    
    # Step 4: Calculate payback
    print("Step 4: Calculating payback period...")
    payback_calc = PaybackCalculator()
    payback = payback_calc.calculate_payback_period(dcf_results['cash_flows'])
    
    print(f"   ✓ Payback: {payback:.2f} years")
    print()
    
    # Step 5: Run risk analysis
    print("Step 5: Running risk analysis...")
    risk_flagger = RiskFlagger()
    risk_flags = risk_flagger.flag_risks(
        irr=actual_irr,
        npv=dcf_results['npv'],
        payback_period=payback,
        credit_volumes=data['carbon_credits_gross'] if 'carbon_credits_gross' in data.columns else None,
        project_costs=data['project_implementation_costs'] if 'project_implementation_costs' in data.columns else None
    )
    
    risk_scorer = RiskScoreCalculator()
    risk_score = risk_scorer.calculate_overall_risk_score(
        irr=actual_irr,
        npv=dcf_results['npv'],
        payback_period=payback,
        credit_volumes=data['carbon_credits_gross'] if 'carbon_credits_gross' in data.columns else None,
        base_prices=data['base_carbon_price'] if 'base_carbon_price' in data.columns else None,
        project_costs=data['project_implementation_costs'] if 'project_implementation_costs' in data.columns else None,
        total_investment=assumptions['rubicon_investment_total']
    )
    
    print(f"   ✓ Risk analysis complete")
    print(f"      Risk Level: {risk_flags.get('risk_level', 'Unknown')}")
    print(f"      Risk Score: {risk_score.get('overall_risk_score', 0):.0f}/100")
    print()
    
    # Step 6: Export to Excel (with template and charts)
    print("Step 6: Exporting to Excel with template and charts...")
    output_file = project_root / "Master_Template_Example_Output.xlsx"
    
    excel_exporter = ExcelExporter()
    excel_exporter.export_model_to_excel(
        filename=str(output_file),
        assumptions=assumptions,
        target_streaming_percentage=assumptions['streaming_percentage_initial'],
        target_irr=target_irr,
        actual_irr=actual_irr,
        valuation_schedule=dcf_results['results_df'],
        payback_period=payback,
        risk_flags=risk_flags,
        risk_score=risk_score,
        use_template=True
    )
    
    print(f"   ✓ Excel file created: {output_file}")
    print()
    print("=" * 70)
    print("COMPLETE")
    print("=" * 70)
    print()
    print(f"Output file: {output_file}")
    print()
    print("The Excel file contains:")
    print("  - Inputs & Assumptions (with charts)")
    print("  - Valuation Schedule (with charts)")
    print("  - Summary & Results (with charts)")
    print("  - Analysis (separator)")
    print("  - Deal Valuation (empty inputs, ready for analysis)")
    print("  - Monte Carlo Results (empty inputs, ready for analysis)")
    print("  - Sensitivity Analysis (empty inputs, ready for analysis)")
    print("  - Breakeven Analysis (empty inputs, ready for analysis)")
    print()
    
    return True

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)

